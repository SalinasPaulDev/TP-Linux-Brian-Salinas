#!/bin/bash
#
# backup_full.sh - Realiza un backup comprimido (.tar.gz) de un directorio
# de origen hacia un directorio de destino, con fecha en el nombre.

mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo ""
    echo "Realiza un backup comprimido (.tar.gz) del directorio <origen>,"
    echo "guardandolo en <destino> con un nombre que incluye la fecha"
    echo "actual en formato YYYYMMDD (ANSI)."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo "  -> genera /backup_dir/log_bkp_20261123.tar.gz"
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda y termina"
}

if [ "$1" = "-help" ]; then
    mostrar_ayuda
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: se requieren exactamente 2 argumentos (origen y destino)."
    mostrar_ayuda
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ] || [ ! -r "$ORIGEN" ]; then
    echo "Error: el sistema de archivos de origen '$ORIGEN' no existe o no esta disponible."
    exit 1
fi

if ! df "$ORIGEN" > /dev/null 2>&1; then
    echo "Error: no se pudo verificar el sistema de archivos de origen '$ORIGEN'."
    exit 1
fi

if [ ! -d "$DESTINO" ] || [ ! -w "$DESTINO" ]; then
    echo "Error: el sistema de archivos de destino '$DESTINO' no existe o no esta disponible."
    exit 1
fi

if ! df "$DESTINO" > /dev/null 2>&1; then
    echo "Error: no se pudo verificar el sistema de archivos de destino '$DESTINO'."
    exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO" "$ORIGEN" 2>/tmp/backup_full_error.log

if [ $? -eq 0 ]; then
    echo "Backup creado exitosamente: $ARCHIVO"
    exit 0
else
    echo "Error al crear el backup. Ver detalle en /tmp/backup_full_error.log"
    exit 1
fi
