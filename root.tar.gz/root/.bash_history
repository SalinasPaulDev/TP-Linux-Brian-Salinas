history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
hostnamectl set-hostname TPServer
hostname
reboot
hostname
clear
cat -etc-apt-sources.list
clear
cat /etc/apt/sources.list
sed -i s/bullseye/bookworm/g /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
ping -c 3 8.8.8.8
ping -c 3 google.com
ping -c 3 deb.debian.org
sed -i s/cdn2-fastly.deb.debian.org/deb.debian.org/g /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
sed -i s/cdn2-fastly.debian.org/deb.debian.org/deb.debian.org/g /etc/apt/sources.list
sed -i s/cdn2-fastly.debian.org/deb.debian.org/deb.debian.org/g /etc/apt/sources.list
clear
sed -i s/cdn2-fastly.debian.org/deb.debian.org/g /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt upgrade -y
cat /etc/debian_version
apt full-upgrade -y
apt autoremove -y
reboot
cat /etc/debian_version
ip a
poweroff
ls
exit
apt install apache2 php libapache2-mod-php -y
php -v
systemctl status apache2
clear
ip a
ls -la /var/www/html
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
rm /var/www/html/index.html
ls -la /var/www/html/index.html
ls -la /var/www/html/
tail -20 /var/log/apache2/error.log
apt install php-mysql -y
systemctl restart apache2
tail -5 /var/log/apache2/error.log
apt install mariadb-server -y
systemctl status mariadb
head -30 /root/Material_Adicional_TPVMCA/db.sql
grep -i mysqli /var/www/html/index.php 
head -15 /var/www/html/index.php 
mysql < /root/Material_Adicional_TPVMCA/db.sql
mysql -e "SHOW DATABASE"
mysql ingenieria -e "SHOW TABLES"
mysql ingenieria -e "SELECT * FROM alumnos"
mysql -e "SHOW DATABASES"
cat /etc/network/interfaces
ip route
vi /etc/network/interfaces
systemctl restart networking
ip a
ping -c 3 192.168.1.1
poweroff
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
cp /var/www/html/index.php  /www_dir/
cp /var/www/html/logo.png /www_dir/
cat /etc/apache2/sites-enabled/000-default.conf
sed -i s#/var/www/html#/www_dir#g /etc/apache2/sites-enabled/000-default.conf 
cat /etc/apache2/sites-enabled/000-default.conf
grep -A 5 "Directory /var/www" /etc/apache2/appache2.conf
ls -la /root/Material_Adicional_TPVMCA
grep -A 5 "Directory /var/www" /etc/apache2/apache2.conf
vi /etc/apache2/apache2.conf
systemctl restart apache2
cat /etc/fstab
vi /etc/fstab 
umount /www_dir
umount /backup_dir
mount -a
df -h
reboot
df -h
cat /proc/partitions
cat /proc/partitions > /opt/particion
cat /opt/particion
ls -ld /var/log /var/logs
mkdir -p /opt/scripts
chmod +x /opt/scripts/backup_full.sh 
ls -la /opt/scripts/
/opt/scripts/backup_full.sh  -help
/opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir/
ls -la /backup_dir/
crontab -e
crontab -l
df -h /backup_dir
ls -la /backup_dir
poweroff
ls -la /opt/scripts
cat > /opt/scripts/backup_full.sh << 'SCRIPT_EOF'
#!/bin/bash
#
# backup_full.sh - Realiza un backup comprimido (.tar.gz) de un directorio
# de origen hacia un directorio de destino, con fecha en el nombre.

mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo ""
    echo "Realiza un backup comprimido (.tar.gz) del directorio <origen>,"
    echo "guardandolo en <destino> con un nombre que incluye la fecha"
    echo "actual en formato YYYYMMDD (ANSI)."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo "  -> genera /backup_dir/log_bkp_20261123.tar.gz"
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda y termina"
}

if [ "$1" = "-help" ]; then
    mostrar_ayuda
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: se requieren exactamente 2 argumentos (origen y destino)."
    mostrar_ayuda
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ] || [ ! -r "$ORIGEN" ]; then
    echo "Error: el sistema de archivos de origen '$ORIGEN' no existe o no esta disponible."
    exit 1
fi

if ! df "$ORIGEN" > /dev/null 2>&1; then
    echo "Error: no se pudo verificar el sistema de archivos de origen '$ORIGEN'."
    exit 1
fi

if [ ! -d "$DESTINO" ] || [ ! -w "$DESTINO" ]; then
    echo "Error: el sistema de archivos de destino '$DESTINO' no existe o no esta disponible."
    exit 1
fi

if ! df "$DESTINO" > /dev/null 2>&1; then
    echo "Error: no se pudo verificar el sistema de archivos de destino '$DESTINO'."
    exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO" "$ORIGEN" 2>/tmp/backup_full_error.log

if [ $? -eq 0 ]; then
    echo "Backup creado exitosamente: $ARCHIVO"
    exit 0
else
    echo "Error al crear el backup. Ver detalle en /tmp/backup_full_error.log"
    exit 1
fi
SCRIPT_EOF

rm /opt/scripts/backup_full.sh
rm /opt/
ls -la /opt/
ls -la /opt/scripts/
cat > /opt/scripts/backup_full.sh << 'SCRIPT_EOF'
#!/bin/bash
#
# backup_full.sh - Realiza un backup comprimido (.tar.gz) de un directorio
# de origen hacia un directorio de destino, con fecha en el nombre.

mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo ""
    echo "Realiza un backup comprimido (.tar.gz) del directorio <origen>,"
    echo "guardandolo en <destino> con un nombre que incluye la fecha"
    echo "actual en formato YYYYMMDD (ANSI)."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo "  -> genera /backup_dir/log_bkp_20261123.tar.gz"
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda y termina"
}

if [ "$1" = "-help" ]; then
    mostrar_ayuda
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: se requieren exactamente 2 argumentos (origen y destino)."
    mostrar_ayuda
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ] || [ ! -r "$ORIGEN" ]; then
    echo "Error: el sistema de archivos de origen '$ORIGEN' no existe o no esta disponible."
    exit 1
fi

if ! df "$ORIGEN" > /dev/null 2>&1; then
    echo "Error: no se pudo verificar el sistema de archivos de origen '$ORIGEN'."
    exit 1
fi

if [ ! -d "$DESTINO" ] || [ ! -w "$DESTINO" ]; then
    echo "Error: el sistema de archivos de destino '$DESTINO' no existe o no esta disponible."
    exit 1
fi

if ! df "$DESTINO" > /dev/null 2>&1; then
    echo "Error: no se pudo verificar el sistema de archivos de destino '$DESTINO'."
    exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO" "$ORIGEN" 2>/tmp/backup_full_error.log

if [ $? -eq 0 ]; then
    echo "Backup creado exitosamente: $ARCHIVO"
    exit 0
else
    echo "Error al crear el backup. Ver detalle en /tmp/backup_full_error.log"
    exit 1
fi
SCRIPT_EOF

